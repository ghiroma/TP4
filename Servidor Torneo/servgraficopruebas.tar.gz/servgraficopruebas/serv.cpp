#include <string.h>
#include <pthread.h>
#include <iostream>
#include <fstream>
#include <unistd.h>
#include <list>
#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>

using namespace std;
static const int ANCHO_PANTALLA_SERVIDOR = 700;
static const int ALTO_PANTALLA_SERVIDOR = 500;
static const int BPP_SERVIDOR = 16;

int main(int argc, char * argv[]) {

	SDL_Surface *screen, *background, *tiempo, *jugadores, *infoJugador;
	SDL_Rect posDestino, posBackground, posTiempo, posJugadores, posInfoJugadores;
	SDL_Color colorNegro, colorBlanco;
	TTF_Font *font;

	//Colores
	colorNegro.r = colorNegro.g = colorNegro.b = 0;
	colorBlanco.r = colorBlanco.g = colorBlanco.b = 255;

	background = SDL_LoadBMP("Img/background.bmp");
	//verificamos si ha ocurrido algun error cargando la imagen 
	if (background == NULL) {
		printf("Error en SDL_LoadBMP= %s\n", SDL_GetError());
		return 1;
	}

	//creo una copia del background
	posBackground.x = 0;
	posBackground.y = 0;
	//SDL_BlitSurface(backgroundOriginal, NULL, background, &posBackground);

	//Inicio modo video
	if (SDL_Init(SDL_INIT_VIDEO) == -1) {
		printf("Error al iniciar SDL: %s\n", SDL_GetError());
		return 1;
	}
	//Inicio modo texto grafico
	if (TTF_Init() < 0) {
		printf("Error al iniciar SDL_TTF\n");
		return 1;
	}

	//Defino las propiedades de la pantalla del juego
	screen = SDL_SetVideoMode(ANCHO_PANTALLA_SERVIDOR, ALTO_PANTALLA_SERVIDOR, BPP_SERVIDOR, SDL_HWSURFACE);
	if (screen == NULL) {
		printf("Error estableciendo el modo de video: %s\n", SDL_GetError());
		return 1;
	}

	//Seteo el titulo de la pantalla
	SDL_WM_SetCaption("Ralph Tournament SERVIDOR", NULL);

	//Cargo la fuente
	font = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 24);
	if (font == NULL) {
		printf("Error abriendo la fuente ttf: %s\n", SDL_GetError());
		return 1;
	}

	///mandar por parametro la duracion a este thread
	int duracionTorneo = 1;
	int minutos = duracionTorneo;
	int segundos = 0;
	posTiempo.x = 50;
	posTiempo.y = 140;
	char txtTiempo[10];
	sprintf(txtTiempo, "TIME %02d:%02d", minutos, segundos);
	tiempo = TTF_RenderText_Solid(font, txtTiempo, colorBlanco);
	SDL_BlitSurface(tiempo, NULL, background, &posTiempo);

	posJugadores.x = 530;
	posJugadores.y = 140;
	char txtPlayers[10];
	sprintf(txtPlayers, "Players: %d", 0);
	jugadores = TTF_RenderText_Solid(font, txtPlayers, colorBlanco);
	SDL_BlitSurface(jugadores, NULL, background, &posJugadores);

	posBackground.x = 0;
	posBackground.y = 0;
	SDL_BlitSurface(background, NULL, screen, &posBackground);
	SDL_Flip(screen);

	sleep(3);

	char txtInfoJugador[50];
	//varaible timeIsUp habilitar cuanto comienze la partida
	while (true) {
		background = SDL_LoadBMP("Img/background.bmp");
		//actualizar tiempo
		if (minutos > 0 && segundos == 0) {
			minutos--;
			segundos = 59;
		} else if (segundos > 0) {
			segundos--;
		}
		if (minutos == 0 && segundos == 0) {
			strcpy(txtTiempo, "Tournament finished, waiting matchs...");
		} else {
			sprintf(txtTiempo, "TIME %02d:%02d", minutos, segundos);
		}
		tiempo = TTF_RenderText_Solid(font, txtTiempo, colorBlanco);
		SDL_BlitSurface(tiempo, NULL, background, &posTiempo);

		//actualizar cantidad de jugadores conectados
		//calcular

		sprintf(txtPlayers, "Players: %d", 0);
		jugadores = TTF_RenderText_Solid(font, txtPlayers, colorBlanco);
		SDL_BlitSurface(jugadores, NULL, background, &posJugadores);

		//actualizar ranking
		//sacar promedios
		posDestino.x = 115;
		posDestino.y = 180;
		int i;
		for (i = 1; i <= 10; ++i) {
			sprintf(txtInfoJugador, "%02d    %-10.10s    %06d    %02d    %02d", i, "peepee7891", 5500, 4, 3);
			infoJugador = TTF_RenderText_Solid(font, txtInfoJugador, colorBlanco);
			SDL_BlitSurface(infoJugador, NULL, background, &posDestino);
			posDestino.y += 30;
		}

		SDL_BlitSurface(background, NULL, screen, &posBackground);
		SDL_Flip(screen);
		usleep(1000000);
	}

	sleep(40);
	SDL_FreeSurface(screen);
	SDL_FreeSurface(background);
	SDL_FreeSurface(tiempo);
	SDL_FreeSurface(jugadores);
	SDL_FreeSurface(infoJugador);
	TTF_CloseFont(font);
	TTF_Quit();
	SDL_Quit();
}
